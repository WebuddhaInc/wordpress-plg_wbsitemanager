=== Webuddha Site Manager ===
Contributors: Webuddha
Tags: remote management, remote security, remote updater, cli updater, package manager, whmcs package manager
Requires at least: 4.0
Tested up to: 4.3.0
Stable tag: 0.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Fetch, List, and Update wordpress core, plugins, and themes remotely or from the command line.

== Description ==

= Webuddha Site Manager =

* List Updates, Fetch Updates, and Run Updates
* Run Remotely or from Command Line
* Responses provided in List or JSON formats for remote integrations
* Built for compatability with WHMCS Site Manager
